/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

/**
 *
 * @author Pawel
 */
@Entity
@Table(name = "cars")
@SecondaryTable(name = "mileages",pkJoinColumns = @PrimaryKeyJoinColumn(name = "id"))
public class CarEntity implements Serializable {

    /**ID of a car*/
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    /**Make of the car*/
    @Column(name = "make")
    private String make;
    /**Model of the car*/
    @Column(name = "model")
    private String model;
    /**Year of production*/
    @Column(name = "year")
    private int year;
    /**Information, if the car is rented*/
    @Column(name = "rented")
    private boolean rented;
    /**Price of every hour of the rent*/
    @Column(name = "hourPrice")
    private float hourPrice;
    /**Last recorded mileage of the car*/
    @JoinColumn(name = "mileage")
    private MileageEntity mileage;

    public MileageEntity getMileage() {
        return mileage;
    }

    public void setMileage(MileageEntity mileage) {
        this.mileage = mileage;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setRented(boolean rented) {
        this.rented = rented;
    }

    public void setHourPrice(float hourPrice) {
        this.hourPrice = hourPrice;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public boolean isRented() {
        return rented;
    }

    public float getHourPrice() {
        return hourPrice;
    }

    public Long getId() {
        return id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CarEntity)) {
            return false;
        }
        CarEntity other = (CarEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.CarEntity[ id=" + id + " ]";
    }
    
}
