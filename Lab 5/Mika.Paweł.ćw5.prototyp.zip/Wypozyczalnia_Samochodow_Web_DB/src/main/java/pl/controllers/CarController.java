/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import pl.entities.CarEntity;
import pl.entities.DateEntity;
import pl.entities.MileageEntity;
import pl.exceptions.MileageException;
import pl.models.Car;
import pl.models.Date;
import pl.models.Mileage;

/**
 *
 * @author Pawel
 */
public class CarController {
    
    EntityManager em;
    
    public CarController(EntityManager Em){
        em=Em;
    }
    
    
    public void InitDates(){
        DateEntity date1 = new DateEntity();     
        date1.setDay(12);
        date1.setMileageID((long)1);
        date1.setMonth(10);
        date1.setYear(2010);
        DateEntity date2 = new DateEntity();
        date2.setYear(1999);
        date2.setMonth(5);
        date2.setDay(12);
        date2.setMileageID((long)2);
        DateEntity date3 = new DateEntity();
        date3.setYear(2010);
        date3.setMonth(10);
        date3.setDay(5);
        date3.setMileageID((long)3);
        DateEntity date4 = new DateEntity();
        date4.setYear(2004);
        date4.setMonth(1);
        date4.setDay(12);
        date4.setMileageID((long)4);
        DateEntity date5 = new DateEntity();
        date5.setYear(2018);
        date5.setMonth(3);
        date5.setDay(7);
        date5.setMileageID((long)5);
        em.getTransaction().begin();
        em.persist(date1);
        //em.persist(date2);
        //em.persist(date3);
        //em.persist(date4);
        //em.persist(date5);
        em.getTransaction().commit();
        em.close();
    }
    
    public void InitMileages(){
        MileageEntity mileage1 = new MileageEntity();
        mileage1.setMileage(0);
        mileage1.setCarID(1);
        MileageEntity mileage2 = new MileageEntity();
        mileage2.setMileage(0);
        mileage2.setCarID(2);
        MileageEntity mileage3 = new MileageEntity();
        mileage3.setMileage(0);
        mileage3.setCarID(3);
        MileageEntity mileage4 = new MileageEntity();
        mileage4.setMileage(0);
        mileage4.setCarID(4);
        MileageEntity mileage5 = new MileageEntity();
        mileage5.setMileage(0);
        mileage5.setCarID(5);
        em.getTransaction().begin();
        em.persist(mileage1);
        em.persist(mileage2);
        em.persist(mileage3);
        em.persist(mileage4);
        em.persist(mileage5);
        em.getTransaction().commit();
        em.close();
    }
    
    public void InitCars(){
        DateEntity date = new DateEntity();
        
        CarEntity car1 = new CarEntity();
        car1.setMake("Mazda");
        car1.setModel("RX8");
        car1.setYear(2010);
        car1.setRented(false);
        car1.setHourPrice(10);
        CarEntity car2 = new CarEntity();
        car2.setMake("Volkswagen");
        car2.setModel("Passat");
        car2.setYear(1999);
        car2.setRented(false);
        car2.setHourPrice(10);
        CarEntity car3 = new CarEntity();
        car3.setMake("BMW");
        car3.setModel("M3 GTR");
        car3.setYear(2005);
        car3.setRented(false);
        car3.setHourPrice(10);
        CarEntity car4 = new CarEntity();
        car4.setMake("Seat");
        car4.setModel("Leon I");
        car4.setYear(2004);
        car4.setRented(false);
        car4.setHourPrice(10);
        CarEntity car5 = new CarEntity();
        car5.setMake("Range Rover");
        car5.setModel("Sport");
        car5.setYear(2004);
        car5.setRented(false);
        car5.setHourPrice(10);
        em.getTransaction().begin();
        em.persist(car1);
        em.persist(car2);
        em.persist(car3);
        em.persist(car4);
        em.persist(car5);
        em.getTransaction().commit();
        em.close(); 
    }
    
    
     /** Function to read the make of the car
     * 
     * @return Make of the car
     */
    public String getMake(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        return car.getMake();
    }
    
    /**Function to read the model of the car
     * 
     * @return Model of the car
     */
    public String getModel(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        return car.getModel();
    }
    
    /**Function to read the year of production of the car
     * 
     * @return Year of production
     */
    public int getYear(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        return car.getYear();
    }
    
    /**Function that checks whether the car is rented
     * 
     * @return true - the car is rented / false - the car is not rented
     */
    public boolean isRented(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        return car.isRented();
    }
    
    /**Function that sets the rented value true
     * 
     */
    public void setRented(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        car.setRented(true);
        em.merge(car);
    }
    
    /**Function that sets the rented value false
     * 
     */
    public void setReturned(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        car.setRented(false);
        em.merge(car);
    }
    
    /**Function that returns the price of one hour rent
     * 
     * @return Price of one hour rent
     */
    public float getPrice(long id){
        CarEntity car;
        car = em.find(CarEntity.class, id);
        return car.getHourPrice();
    }
    
    /**Function that returns the list of the mileage records of the car
     * 
     * @return List of the mileage records of the car
     */
    public List<Mileage> getMileages(long id){
        List<Mileage> mileages;
        mileages = new ArrayList<>();
        CarEntity car;
        car = em.find(CarEntity.class, id);
        MileageEntity mileage = car.getMileage();
        DateEntity date = mileage.getDate();
        Date newDate = new Date(date.getYear(),date.getMonth(),date.getDay());
        Mileage newMileage = new Mileage(newDate, mileage.getMileage());
        mileages.add(newMileage);
        return mileages;
    }
    
    public void addMileage(Mileage add, long id)throws MileageException{
        if(add!=null)
            {
                List<Mileage> mileages;
                mileages = this.getMileages(id);
                Mileage latest = mileages.get(mileages.size()-1);
                if(latest.getDate().isLaterThan(add.getDate()))
                    throw new MileageException("Dodawany przebieg powinien mieć późniejsza datę niż ostatni w liście");
                else if(add.getMileage()<latest.getMileage())
                    throw new MileageException("Dodawany przebieg powinien mieć większą wartość przebiegu niż ostatni w liście");
                 else if(add.getMileage()<0)
                     throw new MileageException("Dodawany przebieg powinien mieć wartość przebiegu większą niż zero");
                 else
                 {
                    CarEntity car;
                    car = em.find(CarEntity.class, id);
                    MileageEntity mileage = car.getMileage();
                    DateEntity date = mileage.getDate();
                    date.setYear(add.getDate().getDate().get(0));
                    date.setMonth(add.getDate().getDate().get(1));
                    date.setDay(add.getDate().getDate().get(2));
                    mileage.setMileage(add.getMileage());
                    em.merge(date);
                    em.merge(mileage);
                 }
            }
            else
                throw new MileageException("Dodawany przebieg nie może być nullem");
    }
    
    /**Function that tries to set the rented value to true if possible
     * 
     * @throws Exception is the car is already rented
     */
    public void tryRent(long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(car.isRented()==true)
            throw new Exception("Samochód jest już wypożyczony");
        else
            this.setRented(id);
    }
    
    /**Function that tries to set the rented value to false if possible
     * 
     * @throws Exception is the car is already returned
     */
    public void tryReturn(long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(car.isRented()==false)
            throw new Exception("Samochód jest już zwrócony");
        else
            this.setReturned(id);
    }
    
    /**Function that sets the new price of an hour rent
     * 
     * @param newPrice New price of an hour rent
     * @throws Exception if the new price is non-postivie
     */
    public void changeRentPrice(float newPrice,long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(newPrice<=0)
            throw new Exception("Nowa cena nie może być mniejsza lub równa zero");
        else
        {
            car.setHourPrice(newPrice);
            em.merge(car);
        }
    }
    
    /**Function that raises the price of an hour rent to the new value
     * 
     * @param newPrice New price of and hour rent
     * @throws Exception if the new price is non-positive or if the new price 
     * is not greater than the previous one
     */
    public void raiseRentPrice(float newPrice,long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(newPrice<=0)
            throw new Exception("Nowa cena nie może być mniejsza lub równa zero");
        else if(newPrice<=car.getHourPrice())
            throw new Exception("Nowa cena nie może być mniejsza lub równa niż poprzednia cena");
        else
        {
            car.setHourPrice(newPrice);
            em.merge(car);
        }
    }
    
    /**Function that raises the price of an hour rent by the given amount
     * 
     * @param amount How much should be added to the price
     * @throws Exception if the new price is non-positive or if the new price 
     * is not greater than the previous one 
     */
    public void raiseRentPriceByAnAmount(float amount,long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(amount<=0)
            throw new Exception("Nowa cena nie może być mniejsza lub równa niż poprzednia cena");
        else
        {
            float price = car.getHourPrice();
            price+=amount;
            car.setHourPrice(price);
            em.merge(car);
        }
    }
    
    /**Function that lowers the price of an hour rent to the new value
     * 
     * @param newPrice New price of an hour rent
     * @throws Exception if the new price is non-positive or if the new price
     * is not lesser than the previous one
     */
    public void lowerRentPrice(float newPrice,long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(newPrice<=0)
            throw new Exception("Nowa cena nie może być mniejsza lub równa zero");
        else if(newPrice>=car.getHourPrice())
            throw new Exception("Nowa cena nie może być większa lub równa niż poprzednia cena");
        else
        {
            car.setHourPrice(newPrice);
            em.merge(car);
        }
    }
    
    /**Function that lowers the price of an hour rent by the given amount
     * 
     * @param amount How much should be substracted from the previous price
     * @throws Exception if the new price is non-positive or if the new price
     * is not lesser than the previous one
     */
    public void lowerRentPriceByAnAmount(float amount,long id) throws Exception{
        CarEntity car;
        car = em.find(CarEntity.class, id);
        if(amount<=0)
            throw new Exception("Nowa cena nie może być większa lub równa niż poprzednia cena");
        else if(car.getHourPrice()-amount<=0)
            throw new Exception("Nowa cena nie może być mniejsza lub równa zero");
        else
        {
            float price = car.getHourPrice();
            price-=amount;
            car.setHourPrice(price);
            em.merge(car);
        }
    }
}
