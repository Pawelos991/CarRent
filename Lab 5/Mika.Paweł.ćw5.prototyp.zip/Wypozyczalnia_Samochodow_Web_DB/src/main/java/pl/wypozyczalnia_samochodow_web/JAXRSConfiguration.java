package pl.wypozyczalnia_samochodow_web;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Configures JAX-RS for the application.
 * @author Pawel
 * @version 1.4
 */
@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {
    
}
