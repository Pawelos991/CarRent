/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.patterns;

import java.util.ArrayList;
import java.util.List;
import pl.controllers.CarController;
import pl.models.Car;
import pl.views.CarView;

/**Manager class for the CarRentPattern
 *
 * @author Pawel Mika
 * @version 1.0
 */
public class CarRentPattern {
    
    /**Main function of the CarRent. Pass no parameters
     * 
     * @param args Arguments passed to function
     */
    public static void main(String args[]){
        List<Car> cars=initializeCars();
        CarView view = new CarView();
        
        CarController controller = new CarController(cars, view);
        
        controller.runTheRent();
    }
    
    /**Function to initialize the table of Cars
     * 
     * @return Initialized table of cars
     */
    private static List<Car> initializeCars()
    {
        List<Car> cars = new ArrayList<>();
        cars.add(new Car("Mazda", "RX8",2010,200000,false,10));
        cars.add(new Car("Volkswagen", "Passat",1999, 350000,false,10));
        cars.add(new Car("BMW", "M3 GTR", 2005,150000,false,10));
        cars.add(new Car("Seat", "Leon I", 2004, 288000,false,10));
        cars.add(new Car("Range Rover", "Sport",2018, 120000,false,10));
        return cars;
    }
}
