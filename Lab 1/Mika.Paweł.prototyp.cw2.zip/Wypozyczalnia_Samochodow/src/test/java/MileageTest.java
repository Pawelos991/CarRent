/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import pl.models.Car;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**Class of the Mileage methods tests
 *
 * @author Pawel
 */
public class MileageTest {
    /**Tested object*/
    private Car car;
    
    /**Function that sets the test car for the mileage methods tests
     * 
     */
    @BeforeEach
    public void setUp() {
        car = new Car("TestCar","TestMileage",2015, 100000,false,15);
    }
    
    /**Function that tests the mileage-related methods in Car model
     * 
     */
    @Test
    public void testAddMileage(){
        try{
            car.addMileage(100);
            assertEquals(car.getMileage(),100100);
        }
        catch(Exception e){
            fail("Adding 100 to the mileage fails");
        }
        
        try{
            car.addMileage(-100);
            fail("An exception should be thrown adding negative value");     
        }
        catch(Exception e){
        }
        try{
            car.addMileage(0);
            fail("An exception should be thrown adding zero value");
        }
        catch(Exception e){
        }
    }
}
