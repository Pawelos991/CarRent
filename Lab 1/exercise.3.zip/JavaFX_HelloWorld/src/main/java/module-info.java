module pl.polsl.lab.javafx_helloworld {
    requires javafx.controls;
    exports pl.polsl.lab.javafx_helloworld;
}
