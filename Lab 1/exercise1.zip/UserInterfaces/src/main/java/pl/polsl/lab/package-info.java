/**
 * Provides two independent applications presenting how to input and present a text
 * 
 */
package pl.polsl.lab;
