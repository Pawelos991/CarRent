/**
 * Covers only one package interface and one public class presenting its implementation. 
 */
package pl.polsl.lab.main;
