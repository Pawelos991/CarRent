/**
 * Provides application presenting how to get command line parameters
 * 
 */
package pl.polsl.lab;
