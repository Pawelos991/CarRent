/**
 * Contains two classes: {@link pl.polsl.anotherPackage.Class1b} and {@link pl.polsl.anotherPackage.Class2b} needed for the demonstration 
 * of keywords: {@code package} and {@code import}.
 */
package pl.polsl.anotherPackage;
