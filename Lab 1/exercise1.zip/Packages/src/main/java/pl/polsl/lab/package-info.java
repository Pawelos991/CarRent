/**
 * Contains {@link pl.polsl.lab.PackageDemo} class and two subpackages for the demonstration 
 * of keywords: {@code package} and {@code import}.
 */
package pl.polsl.lab;
