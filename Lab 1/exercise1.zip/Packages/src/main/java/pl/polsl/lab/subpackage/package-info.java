/**
 * Contains two classes: {@link pl.polsl.lab.subpackage.Class1a} and {@link pl.polsl.lab.subpackage.Class2a} needed for the demonstration 
 * of keywords: {@code package} and {@code import}.
 */
package pl.polsl.lab.subpackage;
