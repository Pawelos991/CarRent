/**
 * Contains four classes describing different approaches to division
 */
package pl.polsl.lab;
