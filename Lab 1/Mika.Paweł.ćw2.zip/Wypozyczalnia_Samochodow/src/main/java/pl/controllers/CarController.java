/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.controllers;

import java.util.ArrayList;
import java.util.List;
import pl.models.Car;
import pl.views.CarView;

/**Car controller class
 *
 * @author Pawel Mika
 * @version 1.1
 */
public class CarController {
    /**Cars table*/
    private List<Car> cars;
    /**View*/
    private CarView view;
    
    /**Car Controller constructor
     * 
     * @param cars Cars table
     * @param view View
     */
    public CarController (List<Car> cars, CarView view){
        this.cars=cars;
        this.view=view;
    }
    
    /**Function to manage the CarRent
     * 
     */
    public void runTheRent(){
        
        String name;
        name = view.displayHello();
        if(name==null)
        {
          return;
        }
        while(true)
        {
            int choice1;
            choice1=view.displayOptions(name);
            if(choice1==0 || choice1==1)
            {
                int choice2 = view.displayCars(cars);
                if(choice1==0)
                {
                    boolean success=tryToRent(choice2);
                    if(success==true)
                    {
                        view.displaySuccessfulRent();
                    }
                    else
                    {
                      view.displayUnsuccessfulRent();  
                    }
                }
                else
                {
                    boolean success=tryToReturn(choice2);
                    if(success==true)
                    {
                        view.displaySuccessfulReturn();
                    }
                    else
                    {
                        view.displayUnsuccessfulReturn();
                    }
                }
            }
            else
            {
                break;
            }
        }
        
    }
    
    /**Function trying to rent a car
     * 
     * @param carNo Number of the car in question
     * @return true - successfully rented a car / false - failed to rent the car
     */
    private boolean tryToRent(int carNo)
    {
       int actualCarNo = carNo-1; 
       boolean isRented = cars.get(actualCarNo).isRented();
       if(isRented==true)
       {
           return false;
       }
       else
       {
           cars.get(actualCarNo).setRented();
           return true;
       }
    }
    
    /**Function trying to return rented car
     * 
     * @param carNo Number of the car in question
     * @return true - successfully returned the car / false - failed to return the car
     */
    private boolean tryToReturn(int carNo)
    {
        int actualCarNo = carNo-1;
        boolean isRented = cars.get(actualCarNo).isRented();
        if(isRented==true)
       {
           cars.get(actualCarNo).setReturned();
           return true;
       }
       else
       {
           return false;
       }
    }
    
}
