/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.views;

import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import pl.models.Car;

/** View class for the CarRent
 *
 * @author Pawel Mika
 * @version 1.1
 */
public class CarView {
    
    /**Function managing the first screen
     * 
     * @return Name of the user 
     */
    public static String displayHello()
    {
        String name = JOptionPane.showInputDialog(null,"Podaj swoje imię","Start",JOptionPane.QUESTION_MESSAGE);
        return name;
        
    }
    
    /**Function that displays the choice that the user has to make
     * Possible options are: rent a car(1), return a car(2), exit(3)
     * @param name Name of the user
     * @return Number of the chosen option(1/2/3)
     */
    public static int displayOptions(String name)
    {
        Object[] options = {"Wypożyczyć auto", "Oddać auto", "Wyjść"};
        int choice = JOptionPane.showOptionDialog(null, "Witaj "+name+"! Co chcesz zrobic?","Wypożyczalnia",JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE,null,options,options[2]);
        return choice;
    }
    
    /**Function to display cars and receive the choice of the user
     * 
     * @param cars Cars table
     * @return Number of the chosen car
     */
    public static int displayCars(List<Car> cars)
    {
        String message = "Wszystkie samochody: ";
        Object[] options={"1","2","3","4","5"};
        cars.stream().forEach(car->{System.out.println("\n"+car.getID()+"."+car.getMake()+"          "+car.getModel()+"          Rocznik:"+car.getYear());});
        
        for(int i=0; i<cars.size(); i++)
        {
            String appen="\n"+(i+1)+"."+cars.get(i).getMake()+"          "+cars.get(i).getModel()+"          Rocznik:"+cars.get(i).getYear();
            message+=appen;
        }
        message+="\n\n\nWybierz samochod:";
        String choiceS = (String)JOptionPane.showInputDialog(null, message,"Wypożyczalnia",JOptionPane.PLAIN_MESSAGE, 
               null,options, "Wybierz numer auta");
        int choice = Integer.parseInt(choiceS);
        return choice;
    }
    
    /**Function that shows a message about successful rent of a car
     * 
     */
    public static void displaySuccessfulRent()
    {
        JOptionPane.showMessageDialog(null, "Udało Ci się wypożyczyć wymarzone auto!","Sukces",JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**Function that shows a message about unsuccessful rent of a car
     * 
     */
    public static void displaySuccessfulReturn()
    {
        JOptionPane.showMessageDialog(null, "Udało Ci się zwrócić wypożyczone auto!\nZapraszamy ponownie!","Sukces",JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**Function that shows a message about successful return of a car
     * 
     */
    public static void displayUnsuccessfulRent()
    {
        JOptionPane.showMessageDialog(null, "Oj!\nNie udało się wypożyczyć auta. Auto jest już wypożyczone.","Błąd",JOptionPane.WARNING_MESSAGE);
    }
    
    /**Function that shows a message about unsuccessful return of a car
     * 
     */
    public static void displayUnsuccessfulReturn()
    {
        JOptionPane.showMessageDialog(null, "Oj!\nNie udało się zwrócić auta. Auto nie jest wypożyczone.","Błąd",JOptionPane.WARNING_MESSAGE);
    }
}
