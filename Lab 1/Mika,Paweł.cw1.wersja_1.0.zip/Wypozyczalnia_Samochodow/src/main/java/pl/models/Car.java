/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.models;

/**Class representing a car
 *
 * @author Pawel Mika
 * @version 1.0
 */
public class Car {
    /**Make of the car*/
    private String make;
    /**Model of the car*/
    private String model;
    /**Year of production*/
    private int year;
    /**Mileage of the car*/
    private int mileage;
    /**Information, if the car is rented*/
    private boolean rented;
    
    /**Contructor of the Car class
     * 
     * @param Make Make of the car
     * @param Model Model of the car
     * @param Year Year of production
     * @param Mileage Mileage of the car
     */
    public Car(String Make, String Model, int Year, int Mileage){
        make=Make;
        model=Model;
        year=Year;
        rented=false;
    }
    /** Function to read the make of the car
     * 
     * @return Make of the car
     */
    public String getMake(){
        return make;
    }
    
    /**Function to read the model of the car
     * 
     * @return Model of the car
     */
    public String getModel(){
        return model;
    }
    
    /**Function to read the year of production of the car
     * 
     * @return Year of production
     */
    public int getYear(){
        return year;
    }
    
    /**Function that checks whether the car is rented
     * 
     * @return true - the car is rented / false - the car is not rented
     */
    public boolean isRented(){
        return rented;
    }
    
    /**Function that sets the rented value true
     * 
     */
    public void setRented(){
        rented=true;
    }
    
    /**Function that sets the rented value false
     * 
     */
    public void setReturned(){
        rented=false;
    }
   
}
