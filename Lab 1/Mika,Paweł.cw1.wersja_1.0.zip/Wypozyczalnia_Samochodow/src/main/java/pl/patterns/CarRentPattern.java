/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.patterns;

import pl.controllers.CarController;
import pl.models.Car;
import pl.views.CarView;

/**Manager class for the CarRentPattern
 *
 * @author Pawel Mika
 * @version 1.0
 */
public class CarRentPattern {
    
    /**Main function of the CarRent. Pass no parameters
     * 
     * @param args Arguments passed to function
     */
    public static void main(String args[]){
        Car cars[]=initializeCars();
        CarView view = new CarView();
        
        CarController controller = new CarController(cars, view);
        
        controller.runTheRent();
    }
    
    /**Function to initialize the table of Cars
     * 
     * @return Initialized table of cars
     */
    private static Car[] initializeCars()
    {
        Car cars[]={new Car("Mazda", "RX8",2010,200000),
                    new Car("Volkswagen", "Passat",1999, 350000),
                    new Car("BMW", "M3 GTR", 2005,150000),
                    new Car("Seat", "Leon I", 2004, 288000),
                    new Car("Range Rover", "Sport",2018, 120000)};
        return cars;
    }
}
